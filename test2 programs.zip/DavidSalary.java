package test2;

import java.util.Scanner;

public class DavidSalary {
	static Scanner s=new Scanner(System.in);
	
	static void basicsalary(){
		System.out.println("enter the basic salary");
		double basicsal=s.nextDouble();
		
		double hras= (50/100)*basicsal;
		System.out.println("hra: " +hras);
		
		double pf=(12/100)*basicsal;
		System.out.println("pf decduction is :" +pf);
		
		double allowance=(75/100)*basicsal;
		System.out.println("special allowance is: "+allowance);
		
		DavidSalary obj=new DavidSalary();
		
		double net=basicsal+hras+allowance-pf;
		System.out.println("the netsalary is: "+net);
		
		
		
	}
	
	void netsalary(){
		
	}
	
	public static void main(String args[]) {
		
		basicsalary();
		
	}

}
