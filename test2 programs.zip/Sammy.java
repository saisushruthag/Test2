package test2;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Sammy {
	
	static String name;
	static long contact;
	static int age;
	static Scanner s=new Scanner(System.in);
	
	Sammy(String name,long contact,int age){
		this.name=name;
		this.contact=contact;
		this.age=age;
	}
	static void details() {
		name=s.next();
		contact=s.nextLong();
		age=s.nextInt();
		ArrayList<Sammy> list=new ArrayList<Sammy>();
		Iterator iterate =list.iterator();
		while(iterate.hasNext()) {
			System.out.println("element : "+iterate.next());
		}
		
		if(age<20||age>55) {
			System.out.println("exception");
		}
		else {
			System.out.println("proceed");
		}
	}
	
	public static void main(String args[]) {
		details();
		
	}

}
