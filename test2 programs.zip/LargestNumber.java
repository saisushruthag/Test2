package test2;

import java.util.Scanner;

public class LargestNumber {
	
	static Scanner s=new Scanner(System.in);
	static void numbers() {
	int n=s.nextInt();
	System.out.println("given number n is "+n);
	
	int d=s.nextInt();
	System.out.println("digit "+d);
	
	
	
	
	System.out.println("the largest number is "+l);
	}
	
	public static void main(String args[]) {
		numbers();
		
	}

}
