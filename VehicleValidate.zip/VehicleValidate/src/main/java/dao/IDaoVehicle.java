package dao;

import java.util.HashMap;
import java.util.Map;

import pojo.ValidityPojo;
import pojo.VehiclePojo;

public interface IDaoVehicle {

	HashMap register();

	ValidityPojo validate();
	
	

}
