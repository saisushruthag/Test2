package dao;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import pojo.ValidityPojo;
import pojo.VehiclePojo;


public class DaoVehicleImpl implements IDaoVehicle {

		ValidityPojo validation=new ValidityPojo();
		VehiclePojo beans=new VehiclePojo();

		HashMap<String,VehiclePojo> map = new HashMap<String,VehiclePojo>(); 
		
		public void register(DaoVehicleImpl reg) {
			//available data
			map.put("TS 09 1234",new VehiclePojo( 2,"2 years","123456781234","9963147724"));
			map.put("TS 09 5678",new VehiclePojo( 4,"5 years","123456781235","8978994294"));
			map.put("TS 09 3456", new VehiclePojo(2,"4 years","8765435678","76545673456"));
			
			
			
			// adding data into the collection
			for(int i=1;i<=2;i++) {
				map.putAll(reg.register());
				map.get(map);
				
			}
			
	}

		public HashMap register() {
			// TODO Auto-generated method stub
			return map;
		}

		public void validate(Date registrationDate, String insurancePeriod, Date expirationDate) {
			
			
			
		}

		public ValidityPojo validate() {
			validation.getExpirationDate();
			validation.getRegistrationDate();
			validation.getRemainingDays();
			
			return validation;
			// TODO Auto-generated method stub
			
		}

		
		
	

}
