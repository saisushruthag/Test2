package ui;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Scanner;

import dao.DaoVehicleImpl;
import dao.IDaoVehicle;
import pojo.ValidityPojo;
import pojo.VehiclePojo;
import service.IServVehicle;
import service.ServVehicleImpl;

public class VehMainUi {
	Scanner sc=new Scanner(System.in);
	VehiclePojo beans=new VehiclePojo();
	ValidityPojo validation=new ValidityPojo();
	SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
	
	static VehMainUi ui=new VehMainUi();
	static IServVehicle servreg=new ServVehicleImpl();
	static IDaoVehicle reg =new DaoVehicleImpl();
	
	void details(HashMap map, Date registrationDate, String insurancePeriod, Date expirationDate){
		
		//select to register or validation check
		System.out.println("enter the choice\n 1. register\n 2.validity check");
		int choice = sc.nextInt();
		
		if(choice==1) {
		
			//user entered registration details
			System.out.println("Enter the vehicle number");
			beans.setVehicleNumber(sc.next());
			System.out.println("enter the type of the vehicle");
			beans.setVehicleType(sc.nextInt());
			System.out.println("enter insurance period");
			beans.setInsurancePeriod(sc.next());
			System.out.println("enter the aadhar number");
			beans.setAadhar(sc.next());
			System.out.println("enter the mobile number");
			beans.setMobile(sc.next());
			
			servreg.register();//calling method in service class
			
			System.out.println(map);
		}
			
			else if(choice ==2) {
			System.out.println("check the validation");
			
			validation.setRegistrationDate(registrationDate);
			beans.setInsurancePeriod(insurancePeriod);
			validation.setExpirationDate(expirationDate);
			
			reg.validate();
			}
			
			else
			
			System.exit(0);
			
		}
	
	
	
	
	public static void main(String args[]) {
		ui.details(servreg.register(), null, null, null);
		
		servreg.validate();

		
	}

}
