package service;

import java.util.Date;
import java.util.HashMap;

import dao.DaoVehicleImpl;
import dao.IDaoVehicle;
import pojo.ValidityPojo;

public class ServVehicleImpl implements IServVehicle {
	static IDaoVehicle reg =new DaoVehicleImpl();


	private HashMap map;

	public HashMap register(HashMap map) {
		return map;
		// TODO Auto-generated method stub
		
	}

	public void registration() {
		// TODO Auto-generated method stub
	}

	public HashMap register() {
		return map;
		// TODO Auto-generated method stub
	}

	public ValidityPojo validate(Date registrationDate, String insurancePeriod, Date expirationDate) {
		// TODO Auto-generated method stub
		return reg.validate();
	}

	public ValidityPojo validate() {
		return null;
		// TODO Auto-generated method stub
		
	}

	
}
