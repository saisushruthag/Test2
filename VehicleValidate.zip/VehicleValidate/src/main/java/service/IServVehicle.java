package service;

import java.util.HashMap;

import pojo.ValidityPojo;

public interface IServVehicle {

	HashMap register();

	ValidityPojo validate();

}
