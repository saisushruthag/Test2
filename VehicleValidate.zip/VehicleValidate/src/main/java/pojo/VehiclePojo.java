package pojo;

import java.util.Date;

public class VehiclePojo {
	
	String vehicleNumber;
	int vehicleType;
	String insurancePeriod;
	String aadhar;
	String mobile;
	
	
	
	public VehiclePojo(int vehicleType, String aadhar, String insurancePeriod, String mobile) {
		this.vehicleType=vehicleType;
		this.aadhar=aadhar;
		this.insurancePeriod=insurancePeriod;
		this.mobile=mobile;
		// TODO Auto-generated constructor stub
	}
	public VehiclePojo() {
		// TODO Auto-generated constructor stub
	}
	public String getVehicleNumber() {
		return vehicleNumber;
	}
	public void setVehicleNumber(String vehicleNumber) {
		this.vehicleNumber = vehicleNumber;
	}
	public int getVehicleType() {
		return vehicleType;
	}
	public void setVehicleType(int vehicleType) {
		this.vehicleType = vehicleType;
	}
	public String getInsurancePeriod() {
		return insurancePeriod;
	}
	public void setInsurancePeriod(String insurancePeriod) {
		this.insurancePeriod = insurancePeriod;
	}
	public String getAadhar() {
		return aadhar;
	}
	public void setAadhar(String aadhar) {
		this.aadhar = aadhar;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	

}
